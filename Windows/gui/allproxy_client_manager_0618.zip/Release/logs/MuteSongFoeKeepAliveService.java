package com.panyun.peerproxyaddin;

import android.app.IntentService;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.PowerManager;
import android.provider.Settings;
import androidx.annotation.Nullable;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.WindowManager;

import com.tencent.bugly.crashreport.CrashReport;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Locale;
public class MuteSongFoeKeepAliveService extends IntentService {
    private PowerManager.WakeLock mWakeLock = null;

    private static String TAG = "peerproxy";
    private static String DEFAULT_CHANNEL_ID = "default_channel";
    private static String DEFAULT_CHANNEL_NAME = "Default";
    private static int NOTIFICATION_ID = 001;
    private static boolean _serviceIsRuning = false;
    private Class _activityClass;

    private MediaPlayer mMediaPlayer;
    private Thread thread;

    public MuteSongFoeKeepAliveService() {
        super("MuteSongFoeKeepAliveService");
    }

    public static void startService(Context context) {
        if (!_serviceIsRuning) {
            _serviceIsRuning = true;
            Log.d(TAG, "start service");

            Intent serviceIntern = new Intent(context, MuteSongFoeKeepAliveService.class);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(serviceIntern);
            } else {
                context.startService(serviceIntern);
            }
        } else {
            Log.d(TAG, "service is running, ignore start service");
        }
    }

    /**
     * 获取唤醒锁
     */
    private void acquireWakeLock() {
        if (mWakeLock == null) {
            PowerManager mPM = (PowerManager) this.getSystemService(Context.POWER_SERVICE);
            mWakeLock = mPM.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK |
                    PowerManager.ON_AFTER_RELEASE, "allproxy:BGServiceAcqLock");
            if (mWakeLock != null) {
                mWakeLock.acquire();
            }
        }
    }

    /**
     * 释放锁
     */
    private void releaseWakeLock() {
        if (mWakeLock != null) {
            mWakeLock.release();
            mWakeLock = null;
        }
    }

    @Override
    protected void onHandleIntent(@Nullable Intent intent) {
        try {
            if (!thread.isAlive()) {
                thread.start();
            }
        } catch (Exception e) {
            Log.d(TAG, "media play thread start faild");
            CrashReport.postCatchedException(e);
        }

        Context context = this.getApplicationContext();
        JSONObject jsonObj = OptionsStorage.GetOptions(context);

        String androidId = Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ANDROID_ID);
        String serverAddr = null;
        try {
            serverAddr = jsonObj.getString("serverAddr");
            String uniqueId = androidId;
            String userId = jsonObj.optString("userId");
            boolean enableHttp = jsonObj.optBoolean("httpProxy");
            boolean enableS5 = jsonObj.optBoolean("socks5Proxy");
            String mainActivity = "net.peerproxy.peerproxy.MainActivity";

            _activityClass = Class.forName(mainActivity);
            this.addIcon(_activityClass);
            Log.d(TAG, "onHandleIntent server address:" + serverAddr + "  UserId: " + userId);

            acquireWakeLock();
            peerproxyClientSdk.PeerproxyClientSdk.connectV2(serverAddr, enableHttp, enableS5, uniqueId, "", userId, getDeviceInfo());
            releaseWakeLock();
            //connect会卡在这里，如果代码执行到这，则说明connect执行结束(一般仅当主动调用disconnect方法后才会到这里)
            //调用stopself方法之后，service会执行onDestory方法
            stopSelf();
            Log.d(TAG, "Conn done");
        } catch (Exception ex) {
            Log.e(TAG, "Connect is failed", ex);
            CrashReport.postCatchedException(ex);
        }
    }

    private void addIcon(Class activityClass) {
        Log.d(TAG, "add notification icon");

        Context context = getApplicationContext();
        NotificationManager mNotificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        Notification.Builder builder;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            //Create channel only if it is not already created
            if (mNotificationManager.getNotificationChannel(DEFAULT_CHANNEL_ID) == null) {
                mNotificationManager.createNotificationChannel(new NotificationChannel(
                        DEFAULT_CHANNEL_ID, DEFAULT_CHANNEL_NAME, NotificationManager.IMPORTANCE_DEFAULT
                ));
            }
            builder = new Notification.Builder(context, DEFAULT_CHANNEL_ID);
        } else {
            builder = new Notification.Builder(context);
        }

        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0,
                new Intent(this, activityClass)
                        .setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP),
                0);
        builder.setSmallIcon(R.drawable.ic_stat_name)
                .setWhen(System.currentTimeMillis())
                .setContentIntent(pendingIntent)
                .setContentText("Proxy is running on background.")
                .setOngoing(true);
        Notification notification = builder.build();
        // mNotificationManager.notify(NOTIFICATION_ID, notification);
        this.startForeground(NOTIFICATION_ID, notification);
    }

    private void deleteIcon() {
        NotificationManager mNotificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        mNotificationManager.cancel(0);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            //Create channel only if it is not already created
            if (mNotificationManager.getNotificationChannel(DEFAULT_CHANNEL_ID) != null) {
                mNotificationManager.deleteNotificationChannel(DEFAULT_CHANNEL_ID);
            }
        }
    }

    @Override
    public void onCreate() {
        super.onCreate();
        MyThread myThread = new MyThread();
        thread = new Thread(myThread);
        mMediaPlayer = MediaPlayer.create(this.getApplicationContext(), R.raw.no_kill);
        mMediaPlayer.setLooping(true);

        Log.d(TAG, "service onCreate ");
    }


    //开始、暂停播放
    private void startPlaySong() {
        try {
            if (mMediaPlayer == null) {
                mMediaPlayer = MediaPlayer.create(this.getApplicationContext(), R.raw.no_kill);
                mMediaPlayer.start();
            } else {
                mMediaPlayer.start();
            }

            Thread.sleep(3000);

            if (mMediaPlayer != null) {
                mMediaPlayer.pause();
            }
        } catch (Exception e) {
            Log.d(TAG, "error in startPlaySong: " + e.toString());
            CrashReport.postCatchedException(e);
        }
    }

    @Override
    public void onDestroy() {
        Log.d(TAG, "onDestroy");
        _serviceIsRuning = false;
        this.deleteIcon();
        super.onDestroy();
        Log.d(TAG, "onDestroy Done");

        mMediaPlayer.pause();

        stopPlaySong();

//        Log.d(TAG, "restart service after service destroy");
//        MuteSongFoeKeepAliveService.startService(getApplicationContext());
    }

    private String getDeviceInfo() {
        JSONObject jsonDevice = new JSONObject();
        try {
            Context context = this.getApplicationContext();

            //硬件制造商（MANUFACTURER）
            String manufacturer = android.os.Build.MANUFACTURER;

            jsonDevice.put("manufacturer", manufacturer);

            //品牌名称（BRAND）
            String brand = android.os.Build.BRAND;
            jsonDevice.put("brand", brand);
            //主板名称（BOARD）
            String board = android.os.Build.BOARD;
            jsonDevice.put("board", board);
            //设备名 （DEVICE）
            String device = android.os.Build.DEVICE;
            jsonDevice.put("device", device);
            //型号（MODEL）
            String model = android.os.Build.MODEL;
            jsonDevice.put("model", model);
            //产品名称（PRODUCT）
            String product = android.os.Build.PRODUCT;
            jsonDevice.put("product", product);
            //设备唯一识别码（FINGERPRINT）
            String fingerprint = android.os.Build.FINGERPRINT;
            jsonDevice.put("fingerprint", fingerprint);
            //CPU指令集（CPU_ABI）
            String cpuAbi = android.os.Build.CPU_ABI;
            jsonDevice.put("cpuAbi", cpuAbi);
            //CPU指令集2（CPU_ABI2）
            String abi2 = android.os.Build.CPU_ABI2;
            jsonDevice.put("cpuAbi2", abi2);
            //硬件序列号（SERIAL）
            String serial = android.os.Build.ID;
            jsonDevice.put("serial", serial);

            jsonDevice.put("verion_release", Build.VERSION.RELEASE);
            jsonDevice.put("verion_SDKINT", Build.VERSION.SDK_INT);
            jsonDevice.put("verion_codename", Build.VERSION.CODENAME);
            jsonDevice.put("hardware", Build.HARDWARE);
            jsonDevice.put("locale", Locale.getDefault().toString());

            WindowManager manager = (WindowManager) context
                    .getSystemService(Context.WINDOW_SERVICE);
            Display display = manager.getDefaultDisplay();
            DisplayMetrics metrics = new DisplayMetrics();
            if(Build.VERSION.SDK_INT < 17) {
                display.getMetrics(metrics);
            } else {
                display.getRealMetrics(metrics);
            }

            jsonDevice.put("dpi_1", metrics.widthPixels + "," + metrics.heightPixels);
            jsonDevice.put("dpi_density", metrics.density);
            jsonDevice.put("dpi_densityDpi", metrics.densityDpi);
        } catch (JSONException e) {
            e.printStackTrace();
            CrashReport.postCatchedException(e);
        }

        return jsonDevice.toString();
    }

    //停止播放销毁对象
    private void stopPlaySong() {
        try {
            if (mMediaPlayer != null) {
                mMediaPlayer.stop();
                mMediaPlayer.reset(); //一些机型上收到mediaplayer went away with unhandled event
                Log.d(TAG, "音乐停止播放,播放对象为：" + mMediaPlayer.hashCode());
                Log.d(TAG, "音乐播放器是否在循环：" + mMediaPlayer.isLooping());
                Log.d(TAG, "音乐播放器是否还在播放：" + mMediaPlayer.isPlaying());
                mMediaPlayer.release();
                Log.d(TAG, "播放对象销毁,播放对象为：" + mMediaPlayer.hashCode());
                mMediaPlayer = null;
            }
        } catch (Exception e) {
            Log.d(TAG, "error in stopPlaySong: " + e.toString());
            CrashReport.postCatchedException(e);
        }
    }

    class MyThread implements Runnable {

        @Override
        public void run() {
            Log.d(TAG, "start media play thread");
            startPlaySong();
        }
    }

}
