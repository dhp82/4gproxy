from __future__ import print_function

import hashlib
import base64

def encrypt2(text):
    m = hashlib.sha256()
    m.update(text)
    return m.hexdigest()
	
def encrypt(text):
    m = hashlib.sha256()
    m.update(text)
    return base64.b64encode(m.hexdigest())
	
print(encrypt2("password"))
print(encrypt("password"))